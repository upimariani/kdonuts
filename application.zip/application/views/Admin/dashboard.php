<!-- dashboard inner -->
<div class="midde_cont">
    <div class="container-fluid">
        <div class="row column_title">
            <div class="col-md-12">
                <div class="page_title">
                    <h2>Dashboard</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12 table-responsive">
                <canvas id="grafik" height="100"></canvas>


            </div>
            <!-- /.col -->
        </div>
    </div>
    <!-- footer -->

</div>
<!-- end dashboard inner -->
</div>
</div>
</div>